﻿using Sitecore.Analytics.Lookups;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class CheckIP : System.Web.UI.Page
    {
        protected void Button1_Click(object sender, EventArgs e)
        {
            var geoObj = LookupManager.GetInformationByIp(TextBox1.Text);
            lblresult.Text = string.Empty;
            lblresult.Text = "IP: " + TextBox1.Text + "<br />";
            lblresult.Text += "AreaCode: " + geoObj.AreaCode + "<br />";
            lblresult.Text += "City: " + geoObj.City + "<br />";
            lblresult.Text += "Country: " + geoObj.Country + "<br />";
            lblresult.Text += "URL: " + geoObj.Url + "<br />";
            lblresult.Text += "Dns: " + geoObj.Dns + "<br />";
            lblresult.Text += "Business Name: " + geoObj.BusinessName + "<br />";
            lblresult.Text += "Isp: " + geoObj.Isp + "<br />";
            lblresult.Text += "Latitude: " + geoObj.Latitude + "<br />";
            lblresult.Text += "Longitude: " + geoObj.Longitude + "<br />";
            lblresult.Text += "MetroCode: " + geoObj.MetroCode + "<br />";
            lblresult.Text += "PostalCode: " + geoObj.PostalCode + "<br />";
            lblresult.Text += "Region: " + geoObj.Region + "<br />";
        }
    }
}